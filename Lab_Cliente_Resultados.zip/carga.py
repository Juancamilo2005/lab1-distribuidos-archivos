"""Anexo A adaptado: valida respuestas, cuenta fallos y guarda datos reales.
--serie ejecuta 3 repeticiones por escenario. La carga repartida usa
tres procesos/consolas, diez clientes por proceso y 200 operaciones por cliente.
"""
import argparse, csv, json, math, os, socket, subprocess, sys, threading, time
from pathlib import Path

BASE = Path(__file__).resolve().parent

def medir(host, puerto, op, clientes, ops, inicio=0):
    partes = op.split()
    a, b = map(float, partes[1:])
    esperado = {"suma": lambda: a+b, "resta": lambda: a-b,
                "multiplica": lambda: a*b, "divide": lambda: a/b}[partes[0]]()
    latencias, errores, lock = [], [], threading.Lock()
    salida = threading.Event()
    def cliente():
        locales, fallos = [], 0
        salida.wait()
        for _ in range(ops):
            t0 = time.perf_counter()
            try:
                with socket.create_connection((host, puerto), timeout=5) as s:
                    s.sendall(op.encode("utf-8"))
                    respuesta = s.recv(1024).decode("utf-8").strip()
                    if not math.isclose(float(respuesta), esperado, rel_tol=1e-9):
                        raise ValueError("Respuesta incorrecta")
                locales.append((time.perf_counter()-t0)*1000)
            except (OSError, ValueError, UnicodeError):
                fallos += 1
        with lock:
            latencias.extend(locales)
            errores.append(fallos)
    hilos = [threading.Thread(target=cliente) for _ in range(clientes)]
    for h in hilos: h.start()
    espera = inicio-time.time()
    if espera > 0: time.sleep(espera)
    comienzo = time.time()
    t0 = time.perf_counter()
    salida.set()
    for h in hilos: h.join()
    duracion = time.perf_counter()-t0
    fin = time.time()
    ok, fallos = len(latencias), sum(errores)
    assert ok+fallos == clientes*ops
    return dict(clientes=clientes, operaciones_ok=ok, fallos=fallos,
                tiempo_s=duracion, rendimiento_ops_s=ok/duracion,
                latencia_ms=sum(latencias)/ok if ok else None,
                inicio=comienzo, fin=fin)

def serie(ops):
    marca = str(time.time_ns())
    archivo = BASE / ("resultados_carga_"+marca+".csv")
    campos = ["escenario", "repeticion", "clientes", "operaciones_ok", "fallos",
              "tiempo_s", "rendimiento_ops_s", "latencia_ms", "inicio", "fin"]
    def guardar(escenario, rep, datos):
        datos = dict(escenario=escenario, repeticion=rep, **datos)
        nuevo = not archivo.exists()
        with archivo.open("a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=campos)
            if nuevo: w.writeheader()
            w.writerow(datos)
        print(json.dumps(datos, ensure_ascii=True), flush=True)
    for n in (1, 5, 10, 20, 50):
        for rep in (1, 2, 3):
            print(f"SUMA: {n} clientes, repeticion {rep}", flush=True)
            guardar("solo_suma_"+str(n), rep,
                    medir("192.168.121.159", 65431, "suma 3 4", n, ops))
    grupos = [("192.168.121.159", 65431, "suma 3 4"),
              ("192.168.121.158", 65432, "resta 10 2"),
              ("192.168.121.140", 65433, "multiplica 5 6")]
    for rep in (1, 2, 3):
        objetivo, trabajos = time.time()+3, []
        for i, (host, puerto, op) in enumerate(grupos):
            ruta = BASE / f"detalle_{marca}_{rep}_{i}.json"
            comando = [sys.executable, str(Path(__file__).resolve()), host, str(puerto),
                       "--op", op, "--clientes", "10", "--ops", str(ops),
                       "--inicio", str(objetivo), "--salida", str(ruta)]
            opciones = {"creationflags": subprocess.CREATE_NEW_CONSOLE} if os.name == "nt" else {}
            trabajos.append((subprocess.Popen(comando, **opciones), ruta))
        for proceso, ruta in trabajos:
            if proceso.wait() != 0: raise RuntimeError("Fallo un proceso: "+str(ruta))
        datos = [json.loads(r.read_text(encoding="utf-8")) for p, r in trabajos]
        inicio, fin = min(d["inicio"] for d in datos), max(d["fin"] for d in datos)
        ok, fallos = sum(d["operaciones_ok"] for d in datos), sum(d["fallos"] for d in datos)
        guardar("repartida_30", rep, dict(clientes=30, operaciones_ok=ok, fallos=fallos,
                tiempo_s=fin-inicio, rendimiento_ops_s=ok/(fin-inicio),
                latencia_ms=sum((d["latencia_ms"] or 0)*d["operaciones_ok"] for d in datos)/ok if ok else None,
                inicio=inicio, fin=fin))
    for rep in (1, 2, 3):
        guardar("solo_suma_30", rep,
                medir("192.168.121.159", 65431, "suma 3 4", 30, ops))
    print("TERMINADO. Archivo: "+str(archivo), flush=True)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("host", nargs="?")
    p.add_argument("puerto", nargs="?", type=int)
    p.add_argument("--op", default="suma 3 4")
    p.add_argument("--clientes", type=int, default=1)
    p.add_argument("--ops", type=int, default=200)
    p.add_argument("--inicio", type=float, default=0)
    p.add_argument("--salida")
    p.add_argument("--serie", action="store_true")
    a = p.parse_args()
    if a.clientes < 1 or a.ops < 1: p.error("clientes y ops deben ser positivos")
    if a.serie:
        serie(a.ops)
    else:
        if not a.host or not a.puerto: p.error("Indique host y puerto")
        r = medir(a.host, a.puerto, a.op, a.clientes, a.ops, a.inicio)
        if a.salida: Path(a.salida).write_text(json.dumps(r), encoding="utf-8")
        print(json.dumps(r), flush=True)
