﻿"""Servicio propio: potencia base exponente. TCP, UTF-8, puerto 65434."""
import math
import socket
import threading

HOST = "0.0.0.0"
PORT = 65434

def calcular(mensaje):
    partes = mensaje.split()
    if len(partes) != 3:
        return "ERROR FORMATO: use potencia base exponente."
    if partes[0] != "potencia":
        return "ERROR OPERACION: este servicio solo acepta potencia."
    try:
        base, exponente = float(partes[1]), float(partes[2])
        if not all(math.isfinite(n) for n in (base, exponente)):
            return "ERROR: los operandos deben ser finitos."
        resultado = math.pow(base, exponente)
        if not math.isfinite(resultado):
            return "ERROR: resultado no finito."
        return str(resultado)
    except ValueError:
        return "ERROR: numeros invalidos o potencia fuera del dominio real."
    except OverflowError:
        return "ERROR: desbordamiento numerico."

def atender(conn, direccion):
    # Compatibilidad con los programas de la guia: solicitud por recv.
    # TCP no garantiza fronteras; queda pendiente implementar enmarcado.
    with conn:
        try:
            while True:
                datos = conn.recv(1024)
                if not datos:
                    break
                mensaje = datos.decode("utf-8").strip()
                if mensaje == "exit":
                    break
                respuesta = calcular(mensaje)
                print(f"[POTENCIA] {direccion}: {mensaje} -> {respuesta}", flush=True)
                conn.sendall((respuesta + "\n").encode("utf-8"))
        except (OSError, UnicodeError) as error:
            print(f"[POTENCIA] Conexion terminada: {type(error).__name__}", flush=True)

if __name__ == "__main__":
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as servidor:
        servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        servidor.bind((HOST, PORT))
        servidor.listen()
        print(f"[POTENCIA] Escuchando en {HOST}:{PORT}", flush=True)
        try:
            while True:
                conn, direccion = servidor.accept()
                threading.Thread(
                    target=atender, args=(conn, direccion), daemon=True
                ).start()
        except KeyboardInterrupt:
            print("\n[POTENCIA] Servidor detenido.")
