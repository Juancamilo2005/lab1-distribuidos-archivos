import socket
import threading

HOST = '0.0.0.0'
PORT = 65432  # Puerto para el servidor de resta

def procesar_operacion(conn):
    while True:
        data = conn.recv(1024)
        if not data:
            break
        operacion = data.decode()
        if operacion == 'exit':
            print("[SERVIDOR RESTA] Comando 'exit' recibido. Cerrando conexión...")
            break

        print(f"[SERVIDOR RESTA] Operacion recibida: {operacion}")
        
        # Realizar la resta
        try:
            _, a, b = operacion.split()
            a, b = float(a), float(b)
            resultado = str(a - b)
        except Exception as e:
            resultado = f"Error: {str(e)}"
        
        conn.sendall(resultado.encode())
    
    conn.close()

def servidor_resta():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[SERVIDOR RESTA] Escuchando en {HOST}:{PORT}...")
        
        while True:
            conn, addr = s.accept()
            print(f"[SERVIDOR RESTA] Conectado con {addr}")
            threading.Thread(target=procesar_operacion, args=(conn,)).start()

if __name__ == "__main__":
    servidor_resta()
