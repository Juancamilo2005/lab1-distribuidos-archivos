import socket
import threading

HOST = '0.0.0.0'
PORT = 65433  # Puerto para el servidor de multiplicación y división

def procesar_operacion(conn):
    while True:
        data = conn.recv(1024)
        if not data:
            break
        operacion = data.decode()
        if operacion == 'exit':
            print("[SERVIDOR MULTIPLICACION/DIVISION] Comando 'exit' recibido. Cerrando conexión...")
            break

        print(f"[SERVIDOR MULTIPLICACION/DIVISION] Operacion recibida: {operacion}")
        
        # Realizar multiplicación o división
        try:
            parts = operacion.split()
            if len(parts) != 3:
                raise ValueError("Operación no válida. Debe ser de la forma: 'operacion num1 num2'")
            
            op, a, b = parts
            a, b = float(a), float(b)
            
            if op == 'multiplica':
                resultado = str(a * b)
            elif op == 'divide':
                if b == 0:
                    resultado = "Error: División por cero"
                else:
                    resultado = str(a / b)
            else:
                resultado = "Operación no reconocida. Use multiplica o divide."
        except Exception as e:
            resultado = f"Error: {str(e)}"
        
        conn.sendall(resultado.encode())
    
    conn.close()

def servidor_multiplicacion_division():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[SERVIDOR MULTIPLICACION/DIVISION] Escuchando en {HOST}:{PORT}...")
        
        while True:
            conn, addr = s.accept()
            print(f"[SERVIDOR MULTIPLICACION/DIVISION] Conectado con {addr}")
            threading.Thread(target=procesar_operacion, args=(conn,)).start()

if __name__ == "__main__":
    servidor_multiplicacion_division()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             