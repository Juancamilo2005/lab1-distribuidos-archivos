"""Servidor de suma mejorado para el Laboratorio 1 de Sistemas Distribuidos.

Derivado de suma.py incluido en ProgsV3.zip. Los comentarios CAMBIO explican
las modificaciones respecto al archivo original. Requiere Python 3.8 o superior.

Uso: python3 suma_v2.py
Solicitud: suma numero1 numero2. Respuesta: resultado o ERROR, seguido de LF.
Se mantiene un hilo por conexión y se permiten varias solicitudes por conexión.

LIMITACIÓN CONSERVADA: por compatibilidad con clientev2.py y carga.py originales,
se interpreta cada recv como una solicitud. TCP no garantiza esas fronteras:
los emisores deben esperar una respuesta antes de enviar la siguiente operación.
Esto NO resuelve la fragmentación ni la unión de mensajes TCP. Un protocolo con
delimitación explícita requeriría actualizar también todos los clientes.
"""

import math
import socket
import threading

# CAMBIO 1: escuchar en las interfaces del equipo sin fijar una IP ajena.
HOST = "0.0.0.0"
PORT = 65431


def procesar_operacion(mensaje):
    """Validar la solicitud y calcular solo sumas de números finitos."""
    partes = mensaje.split()

    # CAMBIO 2: validar cantidad de argumentos y nombre de la operación.
    if len(partes) != 3:
        return "ERROR FORMATO: use suma num1 num2."
    operacion, texto_a, texto_b = partes
    if operacion != "suma":
        return "ERROR OPERACION: este servicio solo acepta suma."

    # CAMBIO 3: mensajes definidos, sin devolver excepciones internas de Python.
    try:
        a, b = float(texto_a), float(texto_b)
    except ValueError:
        return "ERROR NUMERO: ambos operandos deben ser numeros reales."

    # CAMBIO 4: rechazar NaN, infinitos y resultados que desborden float.
    if not math.isfinite(a) or not math.isfinite(b):
        return "ERROR NO_FINITO: los operandos deben ser finitos."
    resultado = a + b
    if not math.isfinite(resultado):
        return "ERROR DESBORDAMIENTO: la suma produce un resultado no finito."
    return str(resultado)


def atender_cliente(conn, addr):
    """Atender una conexión y cerrarla también cuando ocurre un error de red."""
    # CAMBIO 5: el contexto libera la conexión incluso ante desconexiones bruscas.
    try:
        with conn:
            while True:
                datos = conn.recv(1024)
                if not datos:
                    break
                try:
                    mensaje = datos.decode("utf-8").strip()
                except UnicodeDecodeError:
                    conn.sendall(b"ERROR CODIFICACION: use texto UTF-8.\n")
                    continue

                print(f"[SUMA V2] {addr} -> {mensaje!r}", flush=True)
                # CAMBIO 6: reconocer exit también si netcat añade Enter.
                if mensaje.lower() == "exit":
                    break

                respuesta = procesar_operacion(mensaje)
                # CAMBIO 7: separar visualmente las respuestas mediante LF.
                # Esto no convierte recv(1024) en un protocolo delimitado.
                conn.sendall((respuesta + "\n").encode("utf-8"))
    except OSError as error:
        print(f"[SUMA V2] Error de red con {addr}: {error}", flush=True)
    finally:
        print(f"[SUMA V2] Conexion finalizada: {addr}", flush=True)


def servidor_suma():
    """Aceptar clientes y mantener la concurrencia del servidor original."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as servidor:
        # CAMBIO 8: permitir reutilizar la dirección tras cerrar este servidor.
        # No permite ejecutar dos servidores en la misma dirección y puerto.
        servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        servidor.bind((HOST, PORT))
        servidor.listen()
        print(f"[SUMA V2] Escuchando en {HOST}:{PORT}", flush=True)
        try:
            while True:
                conn, addr = servidor.accept()
                print(f"[SUMA V2] Conectado con {addr}", flush=True)
                # CAMBIO 9: los hilos no impiden terminar el proceso principal.
                threading.Thread(
                    target=atender_cliente, args=(conn, addr), daemon=True
                ).start()
        except KeyboardInterrupt:
            print("\n[SUMA V2] Servidor detenido.", flush=True)


if __name__ == "__main__":
    servidor_suma()
