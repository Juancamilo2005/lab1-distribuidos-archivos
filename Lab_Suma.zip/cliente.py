import socket

HOST = '127.0.0.1'  # Cambia a la IP del servidor si es remoto
PORT = 65432

def cliente():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print(f"[CLIENTE] Conectado a la calculadora en {HOST}:{PORT}")
        print("Usa el formato: operacion numero1 numero2")
        print("Operaciones disponibles: suma, resta, multiplica, divide")
        print("Escribe 'salir' para cerrar la conexión.")

        while True:
            mensaje = input("Operacion > ")
            if mensaje.lower() == 'salir':
                break
            s.sendall(mensaje.encode())
            data = s.recv(1024)
            print(f"Resultado: {data.decode()}")

if __name__ == "__main__":
    cliente()

