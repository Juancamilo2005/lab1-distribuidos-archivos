import socket

HOST = '0.0.0.0'
PORT = 65432

def procesar_operacion(mensaje):
    try:
        partes = mensaje.strip().split()
        if len(partes) != 3:
            return "Formato inválido. Usa: operacion num1 num2"

        operacion, a, b = partes[0], float(partes[1]), float(partes[2])

        if operacion == 'suma':
            return str(a + b)
        elif operacion == 'resta':
            return str(a - b)
        elif operacion == 'multiplica':
            return str(a * b)
        elif operacion == 'divide':
            if b == 0:
                return "Error: División por cero"
            return str(a / b)
        else:
            return "Operación no reconocida. Usa: suma, resta, multiplica, divide"
    except Exception as e:
        return f"Error al procesar: {e}"

def servidor():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[SERVIDOR] Calculadora escuchando en {HOST}:{PORT}...")

        conn, addr = s.accept()
        with conn:
            print(f"[SERVIDOR] Conectado con {addr}")
            while True:
                data = conn.recv(1024)
                if not data:
                    print("[SERVIDOR] Cliente desconectado.")
                    break
                mensaje = data.decode()
                print(f"[SERVIDOR] Recibido: {mensaje}")
                resultado = procesar_operacion(mensaje)
                conn.sendall(resultado.encode())

if __name__ == "__main__":
    servidor()

